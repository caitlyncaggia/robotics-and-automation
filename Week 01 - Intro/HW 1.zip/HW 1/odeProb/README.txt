

The homework files are:

  hw1.m			- the main file to run.
  hw1a.m		- the differential equation of part (a).
  hw1b.m		- the differential equation of part (b).


These are optional files for your Matlab pleasure:

  plot1.m		
    - If run after hw1 with part (b) option, then plots the response of the 
      system.

  drawHilare
    - Invoked by plot1 to draw the mobile robot associated to the
	  differential equations integrated in part (b).

