alpha = [pi/2; -pi/3];
l = [1; 0.5];

planarR2_display(alpha, l)