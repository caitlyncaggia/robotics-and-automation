function adot1 = f(t, x)

adot1 = (1/3)*cos(t);

end