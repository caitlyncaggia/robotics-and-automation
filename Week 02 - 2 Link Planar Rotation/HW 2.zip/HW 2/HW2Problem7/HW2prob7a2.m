function adot2 = f(t, x)

adot2 = (-1/4)*sin(t);

end