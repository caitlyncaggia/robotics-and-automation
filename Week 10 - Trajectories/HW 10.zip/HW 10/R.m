function rotMatrix = R(alpha)

    rotMatrix = [cos(alpha) -sin(alpha); sin(alpha) cos(alpha)];

end