% ECE 4560 - Homework 8.3
% Caitlyn Caggia

syms a1 a2 a3 a4 a5 l0 l1 l2 l3 l4;

%translations
T1 = [0; 0; l0]
T2 = [0; 0; 0]
T3 = [0; 0; l1]
T4 = [0; 0; l2]
T5 = [0; 0; l3]
T6 = [0; 0; l4]

%rotations
R1 = SE3.RotZ(a1)
R2 = SE3.RotX(a2)
R3 = SE3.RotX(a3)
R4 = SE3.RotX(a4)
R5 = SE3.RotZ(a5)
R6 = eye(3)

g1 = [R1 T1; 0 0 0 1];
g2 = [R2 T2; 0 0 0 1];
g3 = [R3 T3; 0 0 0 1];
g4 = [R4 T4; 0 0 0 1];
g5 = [R5 T5; 0 0 0 1];
g6 = [R6 T6; 0 0 0 1];
ge = g1*g2*g3*g4*g5*g6;

de = ge(1:3,4)