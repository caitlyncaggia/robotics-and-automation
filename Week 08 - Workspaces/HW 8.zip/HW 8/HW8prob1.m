% ECE 4560 - Homework 8.1
% Caitlyn Caggia

planar_r3(1.5, 1.0, 0.3, 'plot')